import React from "react";

export const FamilyContext = React.createContext();
