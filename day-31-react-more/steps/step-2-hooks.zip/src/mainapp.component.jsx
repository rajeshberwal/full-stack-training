import { Component } from "react";
import ChildComp from "./child.component";
 
class MainApp extends Component{  
    render(){
        return <div>
                    <h1>Welcome To My Application</h1>
                    <hr />
                    <ChildComp />
                </div>
    }
}
 
export default MainApp