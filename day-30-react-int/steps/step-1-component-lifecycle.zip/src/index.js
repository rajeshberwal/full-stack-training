import { createRoot } from 'react-dom/client'
import MainApp from './mainapp.component'

createRoot(document.getElementById('root')).render(<MainApp />);