import { Component } from 'react';
import PropTypes from 'prop-types';

class ChildApp extends Component {
    // static defaultProps = {
    //     title: 'Default Child Title',
    //     version: 10
    // }
    static propTypes = {
        title: PropTypes.string.isRequired,
        version: PropTypes.number.isRequired
    }

    render() {
        return <div>
            {/* <h2>Title: { this.props.title || 'Default Child Title' }</h2>
            <h2>Version: { this.props.version || '5' }</h2> */}
            <h2>Title: { this.props.title }</h2>
            <h2>Version: { this.props.version * 10 }</h2>
        </div>
    }   
}

export default ChildApp;